import faiss
import os
import pickle
import numpy as np
import re
from datetime import datetime
from app.services.embeddings import get_embedding

INDEX_FILE = "faiss_index.bin"
META_FILE = "metadata.pkl"


def normalize_vec(vec: np.ndarray) -> np.ndarray:
    """Return L2-normalized vector for cosine similarity search."""
    norm = np.linalg.norm(vec)
    if norm == 0:
        return vec
    return vec / norm


def load_or_create_index(dim: int = None):
    """Load FAISS index (cosine/IP) and metadata, or create new ones."""
    if dim is None:
        test_vec = get_embedding("hello world")
        if test_vec is None:
            print("[WARN] Could not get real embedding to detect dim — using 768 fallback")
            dim = 768
        else:
            dim = test_vec.shape[0]

    if os.path.exists(INDEX_FILE) and os.path.exists(META_FILE):
        index = faiss.read_index(INDEX_FILE)
        with open(META_FILE, "rb") as f:
            metadata = pickle.load(f)
        print(f"[DEBUG] Loaded FAISS index with {index.ntotal} vectors and {len(metadata)} metadata entries")
        if index.ntotal != len(metadata):
            print(f"[WARN] index.ntotal ({index.ntotal}) != len(metadata) ({len(metadata)}). Possible mismatch.")
    else:
        # Use inner-product index for cosine similarity
        index = faiss.IndexFlatIP(dim)
        metadata = []
        print("[DEBUG] Created new FAISS index (cosine similarity) with dim", dim)

    return index, metadata


def save_index(index, metadata):
    """Persist FAISS index and metadata."""
    faiss.write_index(index, INDEX_FILE)
    with open(META_FILE, "wb") as f:
        pickle.dump(metadata, f)
    print(f"[DEBUG] FAISS index saved. Total vectors: {index.ntotal}")


def add_to_index(chunks, index, metadata, embeddings=None, filename=None):
    """Add document chunks + embeddings to FAISS index."""
    now = datetime.now().timestamp()
    to_add, added_meta = [], []

    for i, chunk in enumerate(chunks):
        vec = None
        if embeddings and i < len(embeddings):
            vec = embeddings[i]
        if vec is None:
            vec = get_embedding(chunk)
        if vec is None:
            print(f"[WARN] Skipping chunk {i+1}/{len(chunks)} from {filename} because embedding failed.")
            continue

        vec = normalize_vec(np.array(vec, dtype="float32"))
        to_add.append(vec)
        added_meta.append({"filename": filename, "text": chunk, "timestamp": now})

    if not to_add:
        print("[WARN] No vectors added to index.")
        return

    arr = np.stack(to_add, axis=0)
    index.add(arr)
    metadata.extend(added_meta)
    save_index(index, metadata)
    print(f"[DEBUG] Added {len(to_add)} vectors from {filename}. New total: {index.ntotal}")


# ---------- NEW/IMPROVED search_index with match + recency rerank ----------
def _token_overlap_score(query: str, text: str) -> float:
    """
    Simple token overlap: (# query tokens present in text) / (# query tokens).
    Returns 0..1. Helps factual, short queries.
    """
    q_toks = re.findall(r"\w+", query.lower())
    if not q_toks:
        return 0.0
    text_toks = set(re.findall(r"\w+", text.lower()))
    matches = sum(1 for t in q_toks if t in text_toks)
    return matches / len(q_toks)


def _recency_score_from_timestamp(timestamp: float, recency_halflife_days: float = 7.0) -> float:
    """
    Recency score in (0,1], halflife expressed in days.
    Newer documents -> score closer to 1. Older -> decays.
    Formula: 1 / (1 + age_days / halflife). (Simple, tunable.)
    """
    now = datetime.now().timestamp()
    age_seconds = max(0.0, now - timestamp)
    age_days = age_seconds / 86400.0
    # avoid division by zero
    return 1.0 / (1.0 + (age_days / max(recency_halflife_days, 1e-6)))


def search_index(
    query: str,
    index,
    metadata,
    top_k: int = 5,
    alpha: float = 0.5,
    beta: float = 0.2,
    gamma: float = 0.3,
    recency_halflife_days: float = 7.0,
):
    """
    Search FAISS index and rerank by:
      final_score = alpha*similarity + beta*recency + gamma*match_score

    - similarity: FAISS inner product (higher is better)
    - recency: 1/(1+age_days/recency_halflife_days)
    - match_score: token overlap between query and chunk

    Defaults favor exact matches moderately (gamma=0.3). Tune alpha/beta/gamma as needed.
    """
    if index.ntotal == 0 or not metadata:
        print("[DEBUG] FAISS index or metadata is empty")
        return []

    vec = get_embedding(query)
    if vec is None:
        print("[WARN] Query embedding failed.")
        return []

    qvec = normalize_vec(vec.astype("float32"))
    search_k = min(max(top_k, 1), index.ntotal)
    D, I = index.search(np.array([qvec], dtype="float32"), search_k)  # inner product (higher = better)

    now = datetime.now().timestamp()
    results = []
    for sim, idx in zip(D[0], I[0]):
        if idx == -1:
            continue
        meta = metadata[idx]
        timestamp = meta.get("timestamp", now)
        recency = _recency_score_from_timestamp(timestamp, recency_halflife_days)
        match_score = _token_overlap_score(query, meta.get("text", ""))

        final_score = alpha * float(sim) + beta * recency + gamma * match_score

        results.append({
            "final_score": final_score,
            "similarity": float(sim),
            "recency": recency,
            "match_score": match_score,
            "text": meta.get("text", ""),
            "filename": meta.get("filename", "unknown"),
            "timestamp": timestamp,
        })

    # sort by final_score descending (best first)
    results.sort(key=lambda x: x["final_score"], reverse=True)

    # debug print top candidates
    print(f"[DEBUG] search_index returned {len(results)} hits (requested top_k={top_k})")
    for i, r in enumerate(results[:top_k]):
        print(
            f"[DEBUG] Hit {i+1}: filename={r['filename']} sim={r['similarity']:.4f} "
            f"recency={r['recency']:.4f} match={r['match_score']:.4f} final={r['final_score']:.4f} "
            f"preview={r['text'][:120]!r}"
        )

    return results[:top_k]
