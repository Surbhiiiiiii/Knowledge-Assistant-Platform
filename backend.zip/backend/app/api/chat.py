from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.services.vectorstore import search_index, load_or_create_index
from app.config import settings
import google.generativeai as genai
import logging

router = APIRouter()
genai.configure(api_key=settings.GEMINI_API_KEY)

class QueryRequest(BaseModel):
    query: str

def build_prompt(context: str, query: str) -> str:
    return f"""
You are a helpful, factual AI assistant. Answer in 2–4 sentences, clearly and politely.

Only use the information provided in the context below.
If the answer is not found there, reply: "I'm sorry, I couldn’t find that in the uploaded documents."

Context:
{context}

Question: {query}

Answer factually and conversationally.
End with: Sources: [file1, file2]
"""

@router.post("/chat")
def chat(req: QueryRequest):
    try:
        logging.info(f"User query: {req.query}")

        # Load global index each request
        index, metadata = load_or_create_index()
        if not index or not metadata or index.ntotal == 0:
            logging.warning("FAISS index empty")
            return {"answer": "No indexed documents available.", "sources": []}

        # Retrieve top relevant chunks across all documents
        hits = search_index(req.query, index, metadata, top_k=min(settings.TOP_K, 10))
        if not hits:
            return {"answer": "No relevant content found.", "sources": []}

        # Deduplicate chunks
        seen_texts = set()
        unique_hits = []
        for h in hits:
            t = h["text"].strip()
            if t not in seen_texts:
                unique_hits.append(h)
                seen_texts.add(t)

        # Build context with multiple documents + section info
        context_parts = []
        for h in unique_hits[:settings.TOP_K]:
            section = h.get("section", "Unknown Section")
            context_parts.append(f"[Source: {h['filename']} | Section: {section}]\n{h['text']}")
        context = "\n\n---\n".join(context_parts)

        # Generate prompt
        prompt = build_prompt(context, req.query)
        logging.info(f"Prompt sent to Gemini (first 300 chars): {prompt[:300]}...")

        # Call Gemini
        model = genai.GenerativeModel(settings.GEMINI_MODEL)
        response = model.generate_content(prompt)
        answer_text = response.text.strip() if response and response.text else "No response from Gemini."

        sources = [{"filename": h["filename"], "text": h["text"][:200]} for h in unique_hits[:settings.TOP_K]]
        return {"answer": answer_text, "sources": sources}

    except Exception as e:
        logging.exception("Chat endpoint failed")
        raise HTTPException(status_code=500, detail=f"Chat endpoint failed: {type(e).__name__}: {e}")
