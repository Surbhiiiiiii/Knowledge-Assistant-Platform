from fastapi import APIRouter, UploadFile, File, HTTPException
import os
from app.config import settings
from app.services.embeddings import embed_document
from app.services.ocr import extract_text_from_pdf, extract_text_from_image
from app.services.vectorstore import load_or_create_index, add_to_index, save_index

router = APIRouter()

@router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    try:
        os.makedirs(settings.STORAGE_PATH, exist_ok=True)
        file_path = os.path.join(settings.STORAGE_PATH, file.filename)

        # Save uploaded file
        content = await file.read()
        with open(file_path, "wb") as f:
            f.write(content)

        # Extract text
        ext = file.filename.lower()
        if ext.endswith(".pdf"):
            text = extract_text_from_pdf(file_path)
        elif ext.endswith((".png", ".jpg", ".jpeg")):
            text = extract_text_from_image(file_path)
        else:
            text = content.decode(errors="ignore")

        if not text or not text.strip():
            raise HTTPException(status_code=400, detail="No extractable text in file.")

        print(f"[DEBUG] Extracted {len(text)} chars from {file.filename}")

        # Load or create global FAISS index
        index, metadata = load_or_create_index()

        # Embed document (section-aware, smaller chunks)
        chunks, embeddings = embed_document(text, chunk_size=settings.CHUNK_SIZE)
        valid_embs = [e for e in embeddings if e is not None]

        if not valid_embs:
            raise HTTPException(status_code=400, detail="Embedding failed for all chunks.")

        add_to_index(
            chunks, index, metadata, embeddings=embeddings, filename=file.filename
        )
        save_index(index, metadata)

        print(f"[DEBUG] Indexed {len(valid_embs)} chunks for {file.filename}")
        return {"message": "File uploaded and indexed successfully", "filename": file.filename, "chunks": len(valid_embs)}

    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Internal error: {type(e).__name__}: {e}")
