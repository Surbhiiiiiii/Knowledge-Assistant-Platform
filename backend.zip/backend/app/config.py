import os
from dotenv import load_dotenv
from pydantic_settings import BaseSettings

# Load .env
load_dotenv()

class Settings(BaseSettings):
    STORAGE_PATH: str = os.getenv("STORAGE_PATH", "./storage")
    VECTOR_PATH: str = os.getenv("VECTOR_INDEX_PATH", "./vectorstore/vector_index.faiss")
    MONGO_URI: str = os.getenv("MONGO_URI", "mongodb://127.0.0.1:27017")
    DB_NAME: str = os.getenv("DB_NAME", "idp_db")

    # Cohere
    COHERE_API_KEY: str = os.getenv("COHERE_API_KEY", "")

    # Gemini
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-1.5-pro")
    GEMINI_EMBEDDING_MODEL: str = os.getenv("GEMINI_EMBEDDING_MODEL", "text-embedding-004")

    # Embedding config
    CHUNK_SIZE: int = int(os.getenv("CHUNK_SIZE", 500))
    CHUNK_OVERLAP: int = int(os.getenv("CHUNK_OVERLAP", 50))
    TOP_K: int = int(os.getenv("TOP_K", 5))

settings = Settings()
